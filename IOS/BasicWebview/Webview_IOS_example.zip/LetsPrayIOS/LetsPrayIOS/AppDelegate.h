//
//  AppDelegate.h
//  LetsPrayIOS
//
//  Created by Jaco Brits on 2018/01/12.
//  Copyright © 2018 Mobilee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

